# React DND TypeScript Starter Repo for CISC275 Fall 2022

Hello! This repository has been pre-configured with eslint and gh-pages to automatically deploy your app when you push to the main branch.

Fork, and execute necessary setup steps.

Watch this space for additional project requirements.
