User 1: Freshman Student
We are an incoming freshman student living in New Caste Hall.
Our main goal is to have a basic idea of our dorm room design.
The nain barrier for our goal is that we are freshman so we have never seen a dorm room and do not know how the dimensions look in reality.

User 2: Sophmore RA Student living in Thomas McKean
We are a sophmore who will be living in a single for the first due to being an RA.
Our main goal is to make the dorm space as cozy as possible now that we are living alone.
The main barrier for our goal is that we have never lived in a single and never had to design a full room alone, and do not know how to fill the space of a room.

User 3: Junior Student living in an Independence triple
We are a junior who has dormed for 4 semesters.
Our main goal is to make sure our furniture fits in our new room.
The main barrier for our goal is for all of our furiture is fit for a different room type, and we do not know if it will fit with 3 people in the room as opposed to our usual double. We need to compare the two rooms, but have no real way to achieve this.
