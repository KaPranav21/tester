export const ItemTypes = {
    PIC: "pic"
};
